package br.com.senai.loja;

import java.math.BigDecimal;
import br.com.senai.loja.imposto.CalculadoraDeImpostos;
import br.com.senai.loja.imposto.ICMS;
import br.com.senai.loja.imposto.IPI;
import br.com.senai.loja.imposto.ISS;
import br.com.senai.loja.imposto.Imposto;
import br.com.senai.loja.orcamento.Orcamento;

public class TestesImpostos {

	public static void main(String[] args) {
		Orcamento orcamento = new Orcamento(new BigDecimal("100"),1);
		CalculadoraDeImpostos calculadora = new CalculadoraDeImpostos();
		System.out.println(calculadora.calcular(orcamento, new ICMS()));
		System.out.println(calculadora.calcular(orcamento, new ISS()));
		System.out.println(calculadora.calcular(orcamento, new IPI()));
	}

}
