package br.com.senai.loja.desconto;

import java.math.BigDecimal;

import br.com.senai.loja.orcamento.Orcamento;

public class CalculadoraDeDescontos {

	public BigDecimal calcular(Orcamento orcamento) {
		Desconto desconto = new DescontoMaiorQueQuinhentos(
				new DescontoMaisDeCincoItens(
						new SemDesconto()));
		
		return desconto.calcular(orcamento);
	}
}
