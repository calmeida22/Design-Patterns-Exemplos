package br.com.senai.loja.pedido.acoes;

import br.com.senai.loja.pedido.Pedido;

public class EnviarEmail implements AcaoAposGerarPedido{

	@Override
	public void executarAcao(Pedido pedido) {
		System.out.println("Enviando email para cliente sobre pedido...");
	}

}
