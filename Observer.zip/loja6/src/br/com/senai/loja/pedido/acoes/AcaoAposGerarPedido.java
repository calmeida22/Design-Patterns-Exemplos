package br.com.senai.loja.pedido.acoes;

import br.com.senai.loja.pedido.Pedido;

public interface AcaoAposGerarPedido {
	
	void executarAcao(Pedido pedido);

}
