package br.com.senai.loja.pedido;

import java.time.LocalDateTime;
import java.util.List;

import br.com.senai.loja.orcamento.Orcamento;
import br.com.senai.loja.pedido.acoes.AcaoAposGerarPedido;

public class GeraPedidoHandler {
	
		private List<AcaoAposGerarPedido> acoesAposGerarPedido; 	
		
		public GeraPedidoHandler(List<AcaoAposGerarPedido> acoesAposGerarPedido) {
			this.acoesAposGerarPedido = acoesAposGerarPedido;
		}
		
		public void executar(GeraPedido dados) {
		Orcamento orcamento = new Orcamento(dados.getValorOrcamento(), dados.getQuantidadeItens());
		Pedido pedido = new Pedido(dados.getCliente(), LocalDateTime.now(), orcamento);
		
		this.acoesAposGerarPedido.forEach(a -> a.executarAcao(pedido));
		
		}	
}
	

