package br.com.senai.loja.orcamento.situacao;

import java.math.BigDecimal;

import br.com.senai.loja.DomainException;
import br.com.senai.loja.orcamento.Orcamento;

public class Reprovado extends SituacaoOrcamento{
	
	public BigDecimal efetuarCalculoDescontoExtra(Orcamento orcamento) {
		throw new DomainException("Orcamento reprovado não pode ter desconto extra");
	}
	
	public void finalizar(Orcamento orcamento) throws DomainException{
		orcamento.setSituacao(new Reprovado());
	}
	
}


