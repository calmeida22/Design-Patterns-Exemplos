package br.com.senai.loja.imposto;

import java.math.BigDecimal;

import br.com.senai.loja.orcamento.Orcamento;

public class CalculadoraDeImpostos {
	public BigDecimal calcular(Orcamento orcamento, TipoImposto tipoImposto ) {
		return tipoImposto.calcular(orcamento);	
	}
}
