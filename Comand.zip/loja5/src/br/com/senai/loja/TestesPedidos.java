package br.com.senai.loja;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import br.com.senai.loja.orcamento.Orcamento;
import br.com.senai.loja.pedido.GeraPedido;
import br.com.senai.loja.pedido.GeraPedidoHandler;
import br.com.senai.loja.pedido.Pedido;

public class TestesPedidos {

	public static void main(String[] args) {
		
		String cliente = "Maria José";
		BigDecimal valorOrcamento = new BigDecimal("600.00");
		int quantidadeItens = 3;
		
		GeraPedido gerador = new GeraPedido(cliente, valorOrcamento, quantidadeItens);
		GeraPedidoHandler handler = new GeraPedidoHandler();
		handler.executar(gerador);
			
	}

}
