package br.com.senai.loja.orcamento.situacao;

import java.math.BigDecimal;

import br.com.senai.loja.DomainException;
import br.com.senai.loja.orcamento.Orcamento;

public class Aprovado extends SituacaoOrcamento {
	
	public BigDecimal efetuarCalculoDescontoExtra(Orcamento orcamento) {
		return orcamento.getValor().multiply(new BigDecimal("0.02"));
	}
	
	public void aprovar(Orcamento orcamento) {
		throw new DomainException ("Orçamento não pode ser aprovado");
	}
	
	public void reprovar(Orcamento orcamento) {
		orcamento.setSituacao(new Aprovado());;
	}

}
