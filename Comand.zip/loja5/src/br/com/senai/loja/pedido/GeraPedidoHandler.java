package br.com.senai.loja.pedido;

import java.time.LocalDateTime;

import br.com.senai.loja.orcamento.Orcamento;

public class GeraPedidoHandler {
	
	//construtor com injeção de dependências
	
	
	public void executar(GeraPedido dados) {
		Orcamento orcamento = new Orcamento(dados.getValorOrcamento(), dados.getQuantidadeItens());
		Pedido pedido = new Pedido(dados.getCliente(), LocalDateTime.now(), orcamento);
	
		System.out.println("Salvar pedido no Banco de dados");
		System.out.println("Enviar email com dados do novo pedido");
	
	}
	

}
