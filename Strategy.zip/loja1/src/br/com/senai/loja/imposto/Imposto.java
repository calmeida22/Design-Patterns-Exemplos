package br.com.senai.loja.imposto;

import java.math.BigDecimal;
import br.com.senai.loja.orcamento.Orcamento;

public interface Imposto {
	BigDecimal calcular (Orcamento orcamento);
}
